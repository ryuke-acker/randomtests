public interface EvilxMBean {
    public String revShell(String host);
}
