## JMX reverse shell

If you found an open JMX port in your nmap scan, this is a pre-built reverse shell ready for you!

An open JMX port looks like this:
```
2979/tcp  open  java-rmi            Java RMI Registry
| rmi-dumpregistry:
|   jmxrmi
|      implements javax.management.remote.rmi.RMIServer,
|     extends
|       java.lang.reflect.Proxy
|       fields
|           Ljava/lang/reflect/InvocationHandler; h
|             java.rmi.server.RemoteObjectInvocationHandler
|             @dcvslx670:41162
|             extends
|_              java.rmi.server.RemoteObject
```

Just open a shell in the `src` subdirectory and run the `runme.sh` script with the following parameters:

- Target hostname
- Target port
- Port number of the local netcat listener you already set up on your workstation (you have one running already don't you?)

Enjoy!

# References
- https://www.optiv.com/blog/exploiting-jmx-rmi
- https://gist.github.com/frohoff/fed1ffaab9b9beeb1c76